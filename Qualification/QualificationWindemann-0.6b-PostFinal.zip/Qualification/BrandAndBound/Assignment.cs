﻿namespace Windemann.HashCode.Qualification
{
    public class Assignment
    {
        public int Value { get; set; }
        public int VehicleId { get; set; }
        public int RideId { get; set; }
    }
}