﻿namespace Windemann.HashCode.Qualification
{
    public class Assignment
    {
        public double Value { get; }
        public int VehicleId { get; }
        public int RideId { get; set; }
    }
}